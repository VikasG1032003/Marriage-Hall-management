How to Run ??
Requirements

Download and Install any local web server such as XAMPP/WAMP.
Download the provided source code zip file. (download button is located below)
Installation/Setup


Enable or Uncomment the GD Library on your php.ini file.
Open your XAMPP/WAMP's Control Panel and start Apache and MySQL.
Extract the downloaded source code zip file.
If you are using XAMPP, copy the extracted source code folder and paste it into the XAMPP's "htdocs" directory. And If you are using WAMP, paste it into the "www" directory.
Browse the PHPMyAdmin in a browser. i.e. http://localhost/phpmyadmin
Create a new database naming whbs_db.
Import the provided SQL file. The file is known as whbs_db.sql located inside the database folder.
Browse the Wedding Hall Booking System in a browser. i.e. http://localhost/whbs/.
Default Admin Access
Username: admin
Password: admin123