#include<stdio.h>
a=2;
b=3;
print("valuee is %d",a+b)
